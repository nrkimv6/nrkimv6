create table admin_user
(
    id              serial
        primary key,
    email           varchar(100)                       not null
        unique,
    name            varchar(50)                        not null,
    password        varchar(50)                        not null,
    role            varchar(10)                        not null,
    created_by      integer                  default 0 not null,
    created_at      timestamp with time zone default CURRENT_TIMESTAMP,
    updated_by      integer                  default 0 not null,
    updated_at      timestamp with time zone default CURRENT_TIMESTAMP,
    last_logined_at timestamp with time zone default CURRENT_TIMESTAMP
);

alter table admin_user
    owner to root;

