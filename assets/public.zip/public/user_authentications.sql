create table user_authentications
(
    user_id      integer      not null
        references users,
    provider     varchar(50)  not null,
    provider_uid varchar(255) not null,
    created_at   timestamp with time zone default now(),
    updated_at   timestamp with time zone default now(),
    primary key (user_id, provider)
);

alter table user_authentications
    owner to root;

