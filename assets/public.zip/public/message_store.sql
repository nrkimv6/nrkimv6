create table message_store
(
    id              serial
        primary key,
    user_id         integer   not null
        references users,
    collection_uuid varchar   not null
        references vectordb_collection,
    message         jsonb     not null,
    created_time    timestamp not null
);

alter table message_store
    owner to root;

