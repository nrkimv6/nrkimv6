create table user_token_usage_histories
(
    id                       serial
        primary key,
    user_id                  integer                                                       not null
        references users,
    created_at               timestamp with time zone default now(),
    token_usage              integer                                                       not null,
    question                 varchar(1024)                                                 not null,
    year_month               varchar(8)                                                    not null,
    llm                      varchar(30)              default 'unknown'::character varying not null,
    is_freetalking           boolean                  default false                        not null,
    bot_type                 varchar(30)              default 'unknown'::character varying not null,
    vectordb_collection_uuid varchar(1024)
        constraint user_token_usage_histories_vectordb_collection_fkey
            references vectordb_collection,
    max_token                integer                  default 0                            not null,
    temperature              integer                  default 0                            not null,
    custom_prompt            text                     default ''::text                     not null,
    cost                     double precision         default 0                            not null,
    prompt_token_usage       integer                  default 0                            not null,
    completion_token_usage   integer                  default 0                            not null,
    prompt_cost              double precision         default 0                            not null,
    completion_cost          double precision         default 0                            not null
);

alter table user_token_usage_histories
    owner to root;

