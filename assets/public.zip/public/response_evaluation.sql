create table response_evaluation
(
    uuid                     varchar not null
        primary key,
    vectordb_collection_uuid varchar
        references vectordb_collection,
    original_message         varchar(4000),
    message                  varchar(4000),
    value                    integer,
    created_time             timestamp default now(),
    modified_time            timestamp default now()
);

alter table response_evaluation
    owner to root;

create index ix_response_evaluation_uuid
    on response_evaluation (uuid);

