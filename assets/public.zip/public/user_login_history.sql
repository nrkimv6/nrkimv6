create table user_login_history
(
    id         serial
        primary key,
    user_id    integer not null
        references users,
    logined_at timestamp with time zone default now(),
    ip_address varchar(50),
    user_agent text
);

alter table user_login_history
    owner to root;

