create table users
(
    id              serial
        primary key,
    is_admin        boolean,
    email           varchar(255) not null
        unique,
    name            varchar(100) not null,
    last_logined_at timestamp with time zone default now(),
    created_at      timestamp with time zone default now(),
    updated_at      timestamp with time zone default now(),
    max_token_size  integer
);

alter table users
    owner to root;

create index ix_users_id
    on users (id);

