create table vectordb_collection_files
(
    id                       serial
        primary key,
    original_filename        varchar(4000),
    stored_filename          varchar(4000),
    vectordb_collection_uuid varchar
        references vectordb_collection,
    created_time             timestamp with time zone default now(),
    modified_time            timestamp with time zone default now()
);

alter table vectordb_collection_files
    owner to root;

