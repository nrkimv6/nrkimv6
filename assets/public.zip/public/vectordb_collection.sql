create table vectordb_collection
(
    uuid                    varchar             not null
        primary key,
    collection_name         varchar(4000),
    display_name            varchar(255),
    bot_type                varchar(30),
    description             text,
    created_time            timestamp with time zone default now(),
    modified_time           timestamp with time zone default now(),
    recommendation_question character varying[] not null,
    summary                 text
);

alter table vectordb_collection
    owner to root;

create index ix_vectordb_collection_uuid
    on vectordb_collection (uuid);

